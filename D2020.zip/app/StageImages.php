<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StageImages extends Model
{
    protected $table = 'stage_images';

    protected $fillable = [
        '',
    ];



}
